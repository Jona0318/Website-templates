# Muse — kunstbenodigdheden Shopify-thema

Importeerbaar Shopify kunstbenodigdheden-thema in wit × violet: kleurrijke hero, materiaal-grid, atelier-sectie, nieuwsbrief en footer. Online Store 2.0 (Liquid), upload-klare zip.

- **Tier:** Premium
- **Sector:** Retail
- **Sfeer:** licht
- **Lettertypen:** Archivo, Inter
- **Technieken:** shopify-os2.0, liquid-sections, theme-settings, product-grid, cart, newsletter

## Gebruiken

Open `index.html` rechtstreeks in je browser — geen build-tools of dependencies nodig.
Een lokale server werkt ook: `python -m http.server` of `npx serve`.

Dit bestand maakt deel uit van de [Bron](../../index.html).

## Licentie

MIT — zie [LICENSE](../../LICENSE) in de hoofdmap.
